WAREHOUSE WORD HUNT - OFFLINE EDITION
=====================================

Use this if the website (chase-mulder.github.io/warehouse-word-hunt) is blocked
or the internet is unreliable. Everything is inside this folder: the game, all
photos, fonts and the intro video. Nothing is downloaded while you play.

HOW TO RUN IT
1. Unzip WarehouseWordHunt-Offline.zip (right-click > Extract All on Windows,
   double-click on a Mac). Do not run it from inside the zip.
2. Open the extracted folder and double-click index.html.
   It opens in your normal browser (Edge, Chrome, Firefox or Safari).
3. Play exactly as on the website. Your progress is saved in that browser.

TO PLAY AS A TEAM IN A TEAMS BREAKOUT ROOM
- One person opens index.html and shares their screen (share the browser window,
  and tick "Include sound" for the intro video).
- The team calls out answers and the sharer types them in.
- Or everyone unzips their own copy and plays on their own laptop.

WHAT IS DIFFERENT OFFLINE
- Shift leaderboard: there is no shared scoreboard. When a team finishes, the
  timer stops and shows their time. Read it out to the moderator, who keeps
  the scores in the chat.
- Station 1 (Hitster): the music clips come from YouTube, so they cannot be
  inside the pack. The moderator plays them for the room (links below), and
  teams answer on screen as normal.
- Intro video: plays from the intro.mp4 file in this folder.
- Everything else (all stations, the card studio, Download card) works the same.

MODERATOR: HITSTER CLIP LINKS (play only the time shown)
  Clip 1  https://www.youtube.com/watch?v=dvgZkm1xWPE   0:00 - 0:30
  Clip 2  https://www.youtube.com/watch?v=xFrGuyw1V8s   0:44 - 1:04
  Clip 3  https://www.youtube.com/watch?v=Zi_XLOBDo_Y   0:00 - 0:30
  Clip 4  https://www.youtube.com/watch?v=eH3giaIzONA   0:30 - 1:00
  Clip 5  https://www.youtube.com/watch?v=fNFzfwLM72c   0:00 - 0:30
If YouTube is blocked too, play the same songs from Spotify or your own music.

TROUBLESHOOTING
- Blank page or no pictures: make sure you unzipped first, and that
  index.html and intro.mp4 are in the same folder.
- Your work laptop blocks opening files in the browser: try a different
  browser, or ask one teammate with a working laptop to share their screen.
- To start over: press "Reset game" at the top of the page.
